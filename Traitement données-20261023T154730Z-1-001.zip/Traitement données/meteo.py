import os
import torch
from PIL import Image
from transformers import CLIPProcessor, CLIPModel

# === 1. Charger CLIP offline ===
local_model_path = "C:/Users/theoc/clip-vit-base-patch32"
model = CLIPModel.from_pretrained(local_model_path, local_files_only=True)
processor = CLIPProcessor.from_pretrained(local_model_path, local_files_only=True)

# === 2. Définir les labels météo avec numéros associés ===
weather_labels = ["sunny", "rainy", "snowy", "cloudy", "stormy", "foggy"]
weather_labels_with_numbers = {label: idx for idx, label in enumerate(weather_labels)}

# === 3. Fonction pour traiter et ajouter les labels météo aux fichiers texte ===
def update_labels_with_weather(image_path, label_file_path, model, processor, weather_labels, weather_labels_with_numbers):
    try:
        image = Image.open(image_path).convert("RGB")
    except Exception as e:
        print(f"❌ Erreur ouverture image {image_path} : {e}")
        return

    inputs = processor(text=weather_labels, images=image, return_tensors="pt", padding=True)

    with torch.no_grad():
        outputs = model(**inputs)
        logits_per_image = outputs.logits_per_image
        probs = logits_per_image.softmax(dim=1)

    predicted_idx = probs.argmax().item()
    predicted_label = weather_labels[predicted_idx]
    predicted_label_number = weather_labels_with_numbers[predicted_label]

    print(f"🌤️ Météo pour {os.path.basename(image_path)} : {predicted_label} ({predicted_label_number})")

    # Lire et modifier le fichier
    with open(label_file_path, 'r') as file:
        lines = [line.strip() for line in file if line.strip()]

    with open(label_file_path, 'w') as file:
        for line in lines:
            parts = line.split()
            if len(parts) == 7:
                # Déjà annoté jour/nuit + météo
                file.write(line + '\n')
            elif len(parts) == 6:
                # Ajouter la météo
                file.write(f"{line} {predicted_label_number}\n")
            else:
                print(f"⚠️ Ligne ignorée (pas au bon format) : {line}")


# === 4. Traitement de toutes les images dans le dossier ===
image_dir = r"C:\Users\theoc\OneDrive\Documents\Yolo\yolov8-python\yolov8-python\data\images\test"
label_dir = r"C:\Users\theoc\OneDrive\Documents\Yolo\yolov8-python\yolov8-python\runs\detect\predictions\predict\labels"  # Dossier des fichiers texte YOLO

for image_name in os.listdir(image_dir):
    if image_name.lower().endswith((".jpg", ".jpeg", ".png", ".bmp", ".gif")):
        # Chemin complet de l'image et du fichier texte
        image_path = os.path.join(image_dir, image_name)
        label_file_path = os.path.join(label_dir, image_name.replace('.jpg', '.txt'))  # Suppose que les fichiers txt ont le même nom que les images
        
        if os.path.exists(label_file_path):
            update_labels_with_weather(image_path, label_file_path, model, processor, weather_labels, weather_labels_with_numbers)
        else:
            print(f"❌ Fichier texte manquant pour l'image {image_name}")

print("✅ Traitement terminé pour toutes les images.")
