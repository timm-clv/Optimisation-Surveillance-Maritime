import os
import cv2
import numpy as np
import csv
import pandas as pd
import matplotlib.pyplot as plt

# --------- Paramètres ---------- 
source_dir = r"C:\Users\theoc\OneDrive\Documents\Yolo\yolov8-python\yolov8-python\data\images\test"  # Dossier des images
destination_dir = source_dir  # Pas de sous-dossier
seuil_luminosite = 75
output_csv = "annotations.csv"

# --------- Détection Jour / Nuit ----------

def detect_day_or_night(image_path, seuil=100):
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ Image illisible : {image_path}")
        return None
    image = cv2.resize(image, (300, 300))
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (15, 15), 0)
    luminosite = np.mean(gray)
    return "Jour" if luminosite > seuil else "Nuit"

# --------- Modification du fichier de label YOLO ----------

def modify_yolo_label(image_name, annotation, label_dir):
    txt_file = os.path.splitext(image_name)[0] + ".txt"
    label_path = os.path.join(label_dir, txt_file)
    if os.path.exists(label_path):
        label_value = 0 if annotation == "Jour" else 1

        with open(label_path, 'r') as f:
            lines = [line.strip() for line in f if line.strip()]

        with open(label_path, 'w') as f:
            for line in lines:
                if len(line.split()) == 6:
                    f.write(line + "\n")
                else:
                    f.write(f"{line} {label_value}\n")

        print(f"✅ Labels mis à jour pour {txt_file} avec '{label_value}'")

# --------- Annotation des images ----------

def annotate_folder(folder_path, label_dir, output_csv, seuil):
    images = [f for f in os.listdir(folder_path) if f.lower().endswith((".jpg", ".jpeg", ".png", ".bmp"))]
    with open(output_csv, mode='w', newline='', encoding='utf-8') as fichier_csv:
        writer = csv.writer(fichier_csv)
        writer.writerow(["image", "annotation"])
        for image_name in images:
            image_path = os.path.join(folder_path, image_name)
            annotation = detect_day_or_night(image_path, seuil)
            if annotation is not None:
                writer.writerow([image_name, annotation])
                modify_yolo_label(image_name, annotation, label_dir)
                print(f"{image_name} → {annotation}")
    print(f"\n✅ Annotation terminée. Résultats dans : {output_csv}")

# --------- Dossier des fichiers de labels YOLO ----------
label_dir = r"C:\Users\theoc\OneDrive\Documents\Yolo\yolov8-python\yolov8-python\runs\detect\predictions\predict\labels"

# --------- Exécution de l'annotation ----------
annotate_folder(destination_dir, label_dir, output_csv, seuil_luminosite)

# --------- Lecture du fichier CSV ----------
df = pd.read_csv(output_csv)
print("\n🧾 Aperçu des annotations :\n", df.head())
print("\n📊 Répartition jour/nuit :\n", df["annotation"].value_counts())

# --------- Affichage du graphique ---------
df["annotation"].value_counts().plot(kind='bar', color=["gold", "midnightblue"])
plt.title("Répartition des images : Jour / Nuit")
plt.xlabel("Annotation")
plt.ylabel("Nombre d'images")
plt.tight_layout()
plt.show()

# --------- Affichage de quelques images ----------
nb_images = min(40, len(df))
fig, axes = plt.subplots(nrows=(nb_images // 4) + 1, ncols=4, figsize=(16, 30))

for i in range(nb_images):
    image_name, annotation = df.iloc[i]
    image_path = os.path.join(destination_dir, image_name)
    image = cv2.imread(image_path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    row, col = i // 4, i % 4
    axes[row, col].imshow(image)
    axes[row, col].set_title(annotation)
    axes[row, col].axis('off')

total_axes = axes.flatten()
for j in range(nb_images, len(total_axes)):
    total_axes[j].axis('off')

plt.tight_layout()
plt.show()
